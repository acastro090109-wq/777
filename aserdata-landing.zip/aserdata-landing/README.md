# ASERDATA — Landing nueva (versión sin cebo)

> Sustituye la landing anterior (`asesorianegociosvirt.com`) por una versión institucional,
> transparente y compatible con la política **"Prácticas comerciales inaceptables"** de
> Google Ads.

Esta es la landing que te recomiendo desplegar **antes** de volver a apelar la suspensión
de tu cuenta de Google Ads. Google revisa el sitio en vivo, no basta con decir "ya lo
arreglé" — tienen que ver un sitio que no dispare las señales rojas que tenían el anterior.

---

## Por qué este rediseño

| Problema del sitio anterior | Cómo lo arregla este |
|---|---|
| "GRATIS" repetido 8+ veces (cebo) | "Sesión de diagnóstico (30 min)" + nota aclarando que NO incluye entregables |
| WhatsApp como único CTA (patrón lead-gen) | Formulario de contacto como canal principal; WhatsApp queda como secundario |
| Titular ≠ contacto (transparencia rota) | Sección "Quiénes somos" explica claramente el rol de Karen (legal) y Diomedes (técnico) |
| Sin NIT, sin dirección, sin email de dominio | Footer + JSON-LD con placeholders `[RELLENAR]` para que pongas tus datos reales |
| Claims inflados sin prueba ("+300", "+200") | Reemplazados por "casos anonimizados" sin números absolutos |
| Términos de 2 líneas | Términos completos (18 secciones) con Ley 1581, Ley 1480, habeas data |
| Política de privacidad inconsistente | Política de privacidad completa (14 secciones) con titular único |
| Banco de datos sin precio | Tabla de tarifas visible con 6 modalidades, política de devolución, derecho de retracto |

---

## Archivos

- `index.html` — landing principal
- `terminos.html` — términos y condiciones completos
- `privacidad.html` — política de privacidad completa
- `README.md` — este archivo

Todo es HTML estático autocontenido. No requiere build ni dependencias. Súbelo a tu hosting
y listo.

---

## Antes de subir, tienes que rellenar esto

Busca en los archivos `[RELLENAR: ...]` y reemplaza con tus datos reales. Si dejas
placeholders, Google los va a detectar y te van a rechazar la apelación otra vez.

### Datos de la empresa (en `index.html` footer, `terminos.html` sección 1, `privacidad.html` sección 1)

- Razón social completa
- NIT / RUT
- Dirección física completa (calle, número, ciudad, departamento)
- Email con **tu dominio propio** (NO Gmail) — esto es crítico, el email de Gmail
  (`diomecuellomoron@gmail.com`) es una de las señales rojas más fuertes para Google.
  Ejemplo: `contacto@asesorianegociosvirt.com`
- Ciudad para jurisdicción (en términos, sección 16)

### Tarifas reales (en `index.html` sección #tarifas)

6 modalidades. Pon precios reales o rangos honestos. Si no tienes precio para alguna
modalidad, mejor quítala de la tabla que dejarla con placeholder.

### Formación y experiencia de Diomedes (en `index.html` sección #equipo)

Títulos reales, certificaciones reales, años reales, sectores reales. Sin inflar.

### Email de habeas data (en `terminos.html` y `privacidad.html`)

Un email específico para temas de privacidad, distinto al de contacto comercial.

### GA4 ID (opcional, en `index.html` script de cookies)

Si quieres analytics, crea una propiedad en Google Analytics 4 y reemplaza
`[RELLENAR: GA4-ID]`. Si no quieres analytics, déjamelo como está y se quedará solo con
cookies técnicas.

### Email del formulario de contacto (en `index.html` form action)

El formulario usa `formsubmit.co` para enviarte los mensajes. Reemplaza
`[RELLENAR: tu-email-de-dominio]` con tu email real. La primera vez que alguien envíe el
formulario, formsubmit te pedirá confirmar la dirección — revisa tu bandeja.

---

## Cómo desplegar

### Opción A: Hosting actual (más simple)

1. Sube los 3 archivos `.html` a la raíz de tu hosting donde está `asesorianegociosvirt.com`,
   reemplazando el index actual.
2. Asegúrate de que el index anterior ya no esté en caché.
3. Sube el sitemap si tienes uno, o crea uno mínimo:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://asesorianegociosvirt.com/</loc>
    <lastmod>2026-06-19</lastmod>
    <changefreq>monthly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://asesorianegociosvirt.com/terminos.html</loc>
    <lastmod>2026-06-19</lastmod>
    <priority>0.5</priority>
  </url>
  <url>
    <loc>https://asesorianegociosvirt.com/privacidad.html</loc>
    <lastmod>2026-06-19</lastmod>
    <priority>0.5</priority>
  </url>
</urlset>
```

### Opción B: Previsualizar primero

Si quieres ver cómo queda antes de publicarlo, simplemente abre `index.html` en tu
navegador. Como todo es HTML estático, se ve exactamente igual que en producción.

---

## Cambios adicionales que Google quiere ver

Más allá de la landing, te recomiendo:

1. **Crear un email con tu dominio propio** (`contacto@asesorianegociosvirt.com`) y
   empezar a usarlo en lugar de Gmail. Es una de las señales rojas más fuertes.

2. **Tener una ficha en Google Business Profile** si la dirección física es real y visitable.
   Esto añade legitimidad brutal para los revisores de Google Ads.

3. **Tener términos firmados y contrato modelo** listo para mostrar. Si en la apelación
   Google te pide pruebas, un PDF con tu contrato + RUT + cámara de comercio es oro.

4. **Sustituir los claims "+300" y "+200"** por números reales verificables. Si no tienes
   los datos, mejor no decir nada. "Años de experiencia en análisis de datos comerciales"
   sin número es mejor que un número inflado.

5. **Quitar el WhatsApp como CTA principal** del anuncio (no solo de la landing). Si en
   el anuncio de Google decías "Escríbenos al WhatsApp", eso refuerza el patrón de cebo.

---

## Próximos pasos

Una vez tengas la landing desplegada y rellena:

1. **Avísame** y arrancamos con la **apelación nueva** — te redacto el texto con el
   ángulo correcto: cambio demostrado + pruebas + explicación de qué era el problema.

2. Si quieres, también reviso el **copy del anuncio** que tenías corriendo (necesito el
   texto exacto del anuncio rechazado) para asegurarnos de que el nuevo anuncio no
   repita el patrón de cebo.

---

## Licencia

Estos archivos son tuyos. Úsalos, modifícalos, publícalos donde quieras.
